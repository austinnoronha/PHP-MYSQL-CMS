<?php
/* @file	ModuleUsers.class.php - Users Class File
 * @date	April 2016
 * @summary	This is users class used to list/add/edit/delete users data
 * @desc	-
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

class ModuleUsers{

	public $module_name;

	function ModuleUsers(){
		$this->_setup_ajax();
		$this->module_name = "users";
	}

	function actions(){
		global $appConfig;

		$action = plugin_param("action");
		$output	= plugin_param("output");
			
		if($action == "list"){
			$this->_listing();
		}
		else{
			plugin_displayview("users", array("module"=>"users"));
		}
	}
	
	function _listing(){
		global $appConfig;

		$format_sql = "SELECT id,usrgroup,usrfullname FROM `tbl_users` WHERE usremail='%s' AND usrpassword='%s'";
				$sql = sprintf($format_sql, $appConfig->db->_clean($inp_email), md5($inp_password));
		    $result_set = $appConfig->db->query($sql);
				if($result_set["num_rows"] > 0 && isset($result_set["allrows"][0])){
					$tmp_set = $result_set["allrows"][0];
				}
	}

	function _setup_ajax(){
		plugin_loadscript("js/module.users.js", "footer");
	}
} 

//EOF ModuleUsers.class.php
?>