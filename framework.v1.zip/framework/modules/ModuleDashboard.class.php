<?php
/* @file	ModuleDashboard.class.php - Dashboard Class File
 * @date	April 2016
 * @summary	This is dashboard class used to list comon backend interface with default widgets
 * @desc	-
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

class ModuleDashboard{
	function ModuleDashboard(){
		$this->_setup_ajax();
	}

	function actions(){
		global $appConfig;

		$action	= plugin_param("action");
		$output = plugin_param("output");

		plugin_displayview("dashboard", array("module"=>"dashboard"));
	}

	function _setup_ajax(){
		//plugin_loadscript("js/module.dashboard.js", "footer");
	}
} 

//EOF ModuleDashboard.class.php
?>