<?php
/* @file	ModuleLogin.class.php - Login Class File
 * @date	April 2016
 * @summary	This is main login class used to authenticate users login
 * @desc	-
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

class ModuleLogin{
	function ModuleLogin(){
		$this->_setup_ajax();
	}

	function actions(){
		global $appConfig;

		$action				= plugin_param("action");
		$output				= plugin_param("output");
		$inp_email		= plugin_param("inp_email");
		$inp_password	= plugin_param("inp_password");


		if($action == "auth"){
			$log_err = array();

			//Validation
			if(strlen($inp_email) < 5){
				$log_err[] = 'Please enter valid username';
			}
			if(strlen($inp_password) <= 3){
				$log_err[] = 'Please enter valid password';
			}	
			
			$tmp_data = array();	
			$tmp_data["status"] = "failure";
			$tmp_data["message"] = "Authentication failed";
			
			//Check if error pr process SQL
			if(count($log_err) > 0){
					$tmp_data["message"] = implode("<br>",$log_err);
			}
			else{
				$format_sql = "SELECT id,usrgroup,usrfullname FROM `tbl_users` WHERE usremail='%s' AND usrpassword='%s'";
				$sql = sprintf($format_sql, $appConfig->db->_clean($inp_email), md5($inp_password));
		    $result_set = $appConfig->db->query($sql);
				if($result_set["num_rows"] > 0 && isset($result_set["allrows"][0])){
					$tmp_set = $result_set["allrows"][0];

					plugin_set_adminlogin($tmp_set["id"]);
					plugin_set_loginemail($inp_email);
					plugin_set_loginname($tmp_set["usrfullname"]);
					plugin_set_uniqid();
					
					$tmp_data["status"] = "success";
					$tmp_data["message"] = "Successful login. <br>Please wait while you are redirected to dashboard.";
					$tmp_data["red"] = get_site_url("mod=dashboard");
				}
			}

			//Push output
			if($output == "json"){
				plugin_outputjson($tmp_data);
			}
			else{
				plugin_displayview("login",$tmp_data,1);
			}
		}	
		else{
			plugin_displayview("login",array(),1);
		}
	}

	function _setup_ajax(){
		plugin_loadscript("js/module.login.js", "footer");
	}
} 

//EOF ModuleLogin.class.php
?>