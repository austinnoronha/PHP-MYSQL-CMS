<?php
/* @file	ModuleLogin.class.php - Login Class File
 * @date	April 2016
 * @summary	This is main login class used to authenticate users login
 * @desc	-
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

class ModuleLogin{
	function ModuleLogin(){
		$this->_setup_ajax();
	}

	function actions(){
		$action			= plugin_param("action");
		$output			= plugin_param("output");
		$inp_email		= plugin_param("inp_email");
		$inp_password	= plugin_param("inp_password");


		if($action == "auth"){
			
			$tmp_data = array();	
			$tmp_data["status"] = "failure";
			$tmp_data["message"] = "Authentication failed";

			if($output == "json"){
				plugin_outputjson($tmp_data);
			}
			else{
				plugin_displayview("login",$tmp_data,1);
			}
		}	
		else{
			plugin_displayview("login",array(),1);
		}
	}

	function _setup_ajax(){
		plugin_loadscript("js/module.login.js", "footer");
	}
} 

//EOF ModuleLogin.class.php
?>