<?php
/* @file	footer.php - Footer
 * @date	April 2016
 * @summary	Footer HTML File
 * @desc	This is the HTML file for Footer
 * @version	1.0
 * @package templates
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
?>

        </div>
        <!-- Main Content Area - Ends
        ================================================== -->
      </div>
    </div>

    <!-- Core JavaScript
    ================================================== -->
    <?php plugin_generate_scripts("footer"); ?>

		<!-- Core JavaScript - Ends
    ================================================== -->
  </body>
</html>