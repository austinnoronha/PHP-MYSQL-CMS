<?php
/* @file	footer.php - Header
 * @date	April 2016
 * @summary	Footer HTML File
 * @desc	This is the HTML file
 * @version	1.0
 * @package templates
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */


//EOF footer.php
?>