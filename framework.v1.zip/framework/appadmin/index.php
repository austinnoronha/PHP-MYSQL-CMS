<?php
/* @file	index.php - Admin Index
 * @date	April 2016
 * @summary	Admin Master Controller
 * @desc	all the app client calls will go thru this index file
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

include_once("./includes/config.inc.php");
$appConfig->is_admin = 1;

plugin_loadscript("js/jquery.min.js", "header");
plugin_loadscript("js/app.js", "header");
plugin_loadscript("css/app.css", "header");
plugin_loadscript("bootstrap/css/bootstrap.min.css", "header");
plugin_loadscript("js/jquery-ui/jquery-ui.min.css", "header");

plugin_loadscript("bootstrap/js/bootstrap.min.js", "footer");
plugin_loadscript("bootstrap/js/holder.min.js", "footer");
plugin_loadscript("js/jquery-ui/jquery-ui.min.js", "footer");

$module = plugin_param("mod");

switch($module){
	default:
	case 'login':{    
	//if(plugin_get_adminlogin()) redirect_page("func=dashboard");
    $obj = new ModuleLogin;
	$res = $obj->actions();
  	break;
  }
}

//EOF index.php
?>