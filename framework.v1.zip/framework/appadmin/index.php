<?php
/* @file	index.php - Admin Index
 * @date	April 2016
 * @summary	Admin Master Controller
 * @desc	all the app client calls will go thru this index file
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

if(basename(dirname(__FILE__)) == "appadmin")
	define("CONF_CWD", str_replace(array("/appadmin", "\appadmin"), "", dirname(__FILE__)));	
else
	define("CONF_CWD", dirname(__FILE__));


include_once("../includes/config.inc.php");
$appConfig->is_admin = 1;

plugin_loadscript("js/jquery.min.js", "header");
plugin_loadscript("js/app.js", "header");
plugin_loadscript("css/app.css", "header");
plugin_loadscript("bootstrap/css/bootstrap.min.css", "header");
plugin_loadscript("bootstrap/js/bootstrap.min.js", "footer");
plugin_loadscript("bootstrap/js/holder.min.js", "footer");
plugin_loadscript("js/jquery-ui/jquery-ui.min.css", "header");
plugin_loadscript("js/jquery-ui/jquery-ui.min.js", "footer");
plugin_loadscript("jquery.bootgrid/jquery.bootgrid.min.css", "header");
plugin_loadscript("jquery.bootgrid/jquery.bootgrid.min.js", "footer");

$module = plugin_param("mod");
$ignore_page_logins = array("login");
if(!plugin_get_adminlogin() && !in_array($module,$ignore_page_logins)) redirect_page("mod=login");

switch($module){
	default:
	case 'login':{
		if(plugin_get_adminlogin()) redirect_page("mod=dashboard");
    $obj = new ModuleLogin;
		$res = $obj->actions();
  	break;
  }

	case 'dashboard':{
		$obj = new ModuleDashboard;
		$res = $obj->actions();
  	break;
  }

	case 'users':{
		$obj = new ModuleUsers;
		$res = $obj->actions();
  	break;
  }
}

//EOF index.php
?>