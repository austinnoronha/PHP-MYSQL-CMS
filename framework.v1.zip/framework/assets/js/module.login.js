/* -----------------------------------------------------------------------------------
 * @file: App Js
 * @descp:  This is a custom JS app function for the NBapp
 * @dependency: jquery 1.10 
 * @date: 01-09-2013
 * @author: AppCoder
 * -----------------------------------------------------------------------------------
 */

$(function(){
   
	var formId = "#frm-sign-in",
		dialogId = "#dialog-ajax-message" ;

	$(dialogId).dialog({
      autoOpen: false,
      show: {
        effect: "fade",
        duration: 1000
      },
      hide: {
        effect: "fade",
        duration: 1000
      }
    });

		
	$(formId).on("submit", function(){

		var url = "?mod=login",
			formValues = appCont.functions.getFormdata(formId),
			callback = function(data){
				appCont.functions.hideAjaxMsg();
				console.log("data",data);
				if(data == false){
					$(dialogId).apped("<p>"+appCont.conf.ajxErr+"</p>")
					$(dialogId).dialog( "open" );
				}
				else{
				
				}
			},
			fnBeforeSend = function(){
				appCont.functions.showAjaxMsg(appCont.conf.ajxMsg);
			};

		appCont.xhr.requestPost(url,callback,formValues,fnBeforeSend);

		
		return false
	});
});