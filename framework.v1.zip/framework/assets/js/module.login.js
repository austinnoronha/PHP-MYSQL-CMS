/* -----------------------------------------------------------------------------------
 * @file: Module.Login Js
 * @desc:  This is Login module js actions & support
 * @dependency: jquery 1.10 
 * @date: 01-09-2013
 * @author: AppCoder
 * -----------------------------------------------------------------------------------
 */

$(function(){
   
	var formId = "#frm-sign-in",
		dialogId = "#dialog-ajax-message" ;

	$(formId).on("submit", function(){
        var inp_email = $("#inp_email", $(this));
        var inp_password = $("#inp_password", $(this));

        appCont.functions.highlightSuccessBox("#inp_email");
        appCont.functions.highlightSuccessBox("#inp_password");

        var err_msg = [];
        if(inp_email.val().length <= 5 || inp_email.val().indexOf("@") == -1){
            err_msg.push("Please enter a valid email id");
            appCont.functions.shakeBox("#inp_email");
            appCont.functions.highlightErrorBox("#inp_email");
        }
        if(inp_password.val().length <= 3){
            err_msg.push("Please enter password");
            appCont.functions.shakeBox("#inp_password");
            appCont.functions.highlightErrorBox("#inp_password");
        }

        if(err_msg.length > 0){
            appCont.functions.showModal("Login Error", err_msg.join("<br>"));
        }
        else{
            var url = "?mod=login",
                formValues = appCont.functions.getFormdata(formId),
                callback = function(data){
                    appCont.functions.hideAjaxMsg();
                    if(data == false){
                        appCont.functions.showModal("Login Error", appCont.conf.ajxErr);
                    }
                    else{
                        var parseData = appCont.xhr.parseData(data);
                        if(parseData.status == "failure"){
                            appCont.functions.showModal("Login Error", parseData.message || "Error in login");
                        }
                        else{
                            appCont.functions.showModal("Login", parseData.message || "Successful");
                            if(parseData.red){
                                setTimeout(function(){
                                    appCont.functions.redpage(parseData.red);
                                }, 3000);
                            }
                        }
                    }
                },
                fnBeforeSend = function(){
                    appCont.functions.showAjaxMsg(appCont.conf.ajxMsg);
                };

            appCont.xhr.requestPost(url,formValues,callback,fnBeforeSend);
        }

		return false
	});
});