/* -----------------------------------------------------------------------------------
 * @file: App Js
 * @descp:  This is a custom JS app function for the NBapp
 * @dependency: jquery 1.10 
 * @date: April 2016
 * @author: AppCoder
 * -----------------------------------------------------------------------------------
 */

var appCont = {};
appCont.conf = {
  ajxMsg:"Please wait, processing your request...",
  ajxErr:"Sorry, the service your trying to reach is currently not responding.<br\/>Kindly try again later.",
  baseurl:""
};

appCont.xhr = {
	requestPost : function(url,callback,formValues,fnBeforeSend){
		if(!url) return;
		fnBeforeSend = fnBeforeSend || function(){};
		formValues = formValues || {};

		url += (url.indexOf("?") !== -1) ? "&output=json":"?output=json";
		
		var custHeaders = {};
		//custHeaders["Content-type"] = "application/x-www-form-urlencoded";

		var that=this;
		var ajaxSetup = {
		  url: url,
		  cache:false,
		  data:formValues,
		  type: "POST",
		  headers:custHeaders,
		  beforeSend: fnBeforeSend,
		  success: function(data,textStatus,jqXHR){
			var jsonData = {};
			try{
				jsonData = $.parseJSON(data);
			}
			catch(e){
				jsonData = eval('('+data+')');
			}
			callback(jsonData, textStatus);
		  },
		  error: function(jqXHR,textStatus,errorThrown){
			console.log("[error] textStatus",textStatus,errorThrown);
			callback(false,false);
		  },
		  complete: function(){			
		  }
		};
		$.ajax(ajaxSetup);
		
	}
};

appCont.functions = {
  getFormdata : function(formName){
		return (formName) ? $(formName).serialize() : '';
  },
  
  showAjaxMsg:function(msg){
	$("#ajxmsgbox").html("").html(msg);	
    $("#ajxmsgbox").css("left", (($(window).width()-$("#ajxmsgbox").outerWidth())/2)).show();
  },

  hideAjaxMsg:function(msg){
	$("#ajxmsgbox").html("").hide(0);
  },
  	
  attachFuncOnload:function(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
      window.onload = func;
    } else {
      window.onload = function() {
        if (oldonload) {
        oldonload();
        }
        func();
      }
    }
  },
  redpage: function(url){
    if(url != ""){
      var browser_type=navigator.appName
      var browser_version=parseInt(navigator.appVersion)
      if (browser_type=="Netscape"&&browser_version>=4){
        //if NS 4+	
        window.location.replace(url);
      }else if (browser_type=="Microsoft Internet Explorer"&&browser_version>=4){
        //if IE 4+	
        window.location.replace(url);
      }else{
        //Default goto page (NOT NS 4+ and NOT IE 4+)	
        window.location=url;	
      }
    }
  },
  shakeBox: function(obj){
    var shakeMar = "10px";
    obj.animate({"margin-left":"+="+shakeMar}, "slow", "swing", function(){})
       .animate({"margin-left":"-="+shakeMar}, "slow", "swing", function(){})
       .animate({"margin-left":"+="+shakeMar}, "slow", "swing", function(){})
       .animate({"margin-left":"-="+shakeMar}, "slow", "swing", function(){}); 
    return;
  },
  scrollTop: function(position){
    position = position || 30;
    $('html,body').animate({scrollTop: position}, 1000);
    return;
  }
};