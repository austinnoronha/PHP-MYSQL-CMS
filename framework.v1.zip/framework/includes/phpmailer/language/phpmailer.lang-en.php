<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Spanish version
* Versión en español
* Edited by Matt Sturdy - matt.sturdy@gmail.com
*/

$PHPMAILER_LANG['authenticate']         = 'Error SMTP: Authentication required.';
$PHPMAILER_LANG['connect_host']         = 'Error SMTP: Coul not connect to SMTP.';
$PHPMAILER_LANG['data_not_accepted']    = 'Error SMTP: Data not accepted';
$PHPMAILER_LANG['empty_message']        = 'Message is empty';
$PHPMAILER_LANG['encoding']             = 'Encoding issue: ';
$PHPMAILER_LANG['execute']              = 'Could not execute: ';
$PHPMAILER_LANG['file_access']          = 'Not able to access file: ';
$PHPMAILER_LANG['file_open']            = 'Error not able to open file: ';
$PHPMAILER_LANG['from_failed']          = 'Form Failed: ';
$PHPMAILER_LANG['instantiate']          = 'Could not create instance of function Mail.';
$PHPMAILER_LANG['invalid_address']      = 'Invalid email address: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' Mailer not supported.';
$PHPMAILER_LANG['provide_address']      = 'Provide address to destination.';
$PHPMAILER_LANG['recipients_failed']    = 'Error SMTP: Recipients failed: ';
$PHPMAILER_LANG['signing']              = 'Error in signing mail: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() Failed.';
$PHPMAILER_LANG['smtp_error']           = 'Error service SMTP: ';
$PHPMAILER_LANG['variable_set']         = 'No able to set variable: ';
