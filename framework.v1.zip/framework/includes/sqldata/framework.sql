-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2016 at 12:05 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `framework`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_articles`
--

CREATE TABLE IF NOT EXISTS `tbl_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `aparent` int(11) NOT NULL DEFAULT '0',
  `atitle` varchar(255) NOT NULL,
  `asefurl` varchar(255) NOT NULL,
  `ashortdesc` text NOT NULL,
  `adesc` longtext NOT NULL,
  `ametadesc` text NOT NULL,
  `ametakeywords` text NOT NULL,
  `aimg` varchar(255) NOT NULL,
  `amedia` varchar(255) NOT NULL,
  `astatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `atitle` (`atitle`),
  KEY `asefurl` (`asefurl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_articles`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE IF NOT EXISTS `tbl_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ccategory` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 => "Articles", 	2 => "Testimonials", 	3 => "Gallery"',
  `ccomment` text NOT NULL,
  `cemail` varchar(255) NOT NULL,
  `cip` varchar(255) NOT NULL,
  `cref` varchar(255) NOT NULL,
  `cuseragent` text NOT NULL,
  `cstatus` tinyint(1) NOT NULL DEFAULT '0',
  `capproved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 => Not Approved, 1 => Approved',
  `capproveddt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `capprovedby` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cemail` (`cemail`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_contacts`
--

CREATE TABLE IF NOT EXISTS `tbl_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cto` varchar(255) NOT NULL,
  `csubject` text NOT NULL,
  `cmailbody` text NOT NULL,
  `cresponse` tinyint(1) NOT NULL DEFAULT '0',
  `cstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cto` (`cto`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_contacts`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_enquiry`
--

CREATE TABLE IF NOT EXISTS `tbl_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enname` varchar(255) NOT NULL,
  `enemail` varchar(255) NOT NULL,
  `enphone` varchar(25) NOT NULL,
  `enmobile` varchar(25) NOT NULL,
  `enaddress` text NOT NULL,
  `enpostcode` varchar(10) NOT NULL,
  `enstate` varchar(255) NOT NULL,
  `encountry` varchar(255) NOT NULL,
  `encomment` text NOT NULL,
  `enregarding` varchar(255) NOT NULL,
  `entimetocontact` varchar(255) NOT NULL,
  `enstudenttype` varchar(255) NOT NULL,
  `enuploads` text NOT NULL,
  `enip` varchar(25) NOT NULL,
  `enref` text NOT NULL,
  `enuseragent` text NOT NULL,
  `enreplysent` tinyint(1) NOT NULL DEFAULT '0',
  `enstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `enname` (`enname`),
  KEY `enemail` (`enemail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_enquiry`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_faq`
--

CREATE TABLE IF NOT EXISTS `tbl_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fcat` int(11) NOT NULL DEFAULT '1',
  `ftitle` varchar(255) NOT NULL,
  `fsefurl` varchar(255) NOT NULL,
  `finfo` text NOT NULL,
  `furl` text NOT NULL,
  `femail` varchar(255) NOT NULL,
  `fimg` varchar(255) NOT NULL,
  `fstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ftitle` (`ftitle`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_faq`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE IF NOT EXISTS `tbl_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `albid` int(11) NOT NULL DEFAULT '0',
  `gtitle` varchar(255) NOT NULL,
  `gdesc` text NOT NULL,
  `gurl` text NOT NULL,
  `gimg` varchar(255) NOT NULL,
  `gstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `gtitle` (`gtitle`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `tbl_gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery_album`
--

CREATE TABLE IF NOT EXISTS `tbl_gallery_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `albtitle` varchar(255) NOT NULL,
  `albdesc` text NOT NULL,
  `albimg` varchar(255) NOT NULL,
  `albstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `albtitle` (`albtitle`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_gallery_album`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ncat` int(11) NOT NULL DEFAULT '1',
  `ntitle` varchar(255) NOT NULL,
  `nsefurl` varchar(255) NOT NULL,
  `ninfo` text NOT NULL,
  `nurl` text NOT NULL,
  `nemail` varchar(255) NOT NULL,
  `nstartdate` datetime NOT NULL,
  `nenddate` datetime NOT NULL,
  `nimg` varchar(255) NOT NULL,
  `nstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ntitle` (`ntitle`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_news`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE IF NOT EXISTS `tbl_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stype` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1 => "RSS/Atom Feeds", 	2 => "Footer Short Content", 	3 => "Footer Links"',
  `sformfields` longtext NOT NULL,
  `sstatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_settings`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_subscriber`
--

CREATE TABLE IF NOT EXISTS `tbl_subscriber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(255) NOT NULL,
  `subemail` varchar(255) NOT NULL,
  `subcat` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => General Newsletter',
  `substatus` tinyint(1) NOT NULL DEFAULT '0',
  `subip` varchar(255) NOT NULL,
  `subref` varchar(255) NOT NULL,
  `subuseragent` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_subscriber`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_subscription`
--

CREATE TABLE IF NOT EXISTS `tbl_subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subtitle` varchar(255) NOT NULL,
  `subcode` varchar(50) NOT NULL,
  `subdesc` text NOT NULL,
  `subeditor` varchar(255) NOT NULL,
  `subpub` varchar(255) NOT NULL,
  `subpubdt` date NOT NULL,
  `subprice` double(10,2) NOT NULL,
  `subimg` varchar(255) NOT NULL,
  `submedia` varchar(255) NOT NULL,
  `substatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_subscription`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_testimonials`
--

CREATE TABLE IF NOT EXISTS `tbl_testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testfullname` varchar(255) NOT NULL,
  `testemail` varchar(255) NOT NULL,
  `testphonno` varchar(25) NOT NULL,
  `testcompany` varchar(255) NOT NULL,
  `testcomment` text NOT NULL,
  `testsefurl` varchar(255) NOT NULL,
  `testimg` varchar(255) NOT NULL,
  `testip` varchar(25) NOT NULL,
  `testref` varchar(255) NOT NULL,
  `testuseragent` text NOT NULL,
  `testaddedbyadmin` tinyint(1) NOT NULL DEFAULT '0',
  `teststatus` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `testemail` (`testemail`),
  KEY `testcompany` (`testcompany`),
  KEY `testsefurl` (`testsefurl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_testimonials`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usrgroup` set('admin','root','user','company') NOT NULL DEFAULT 'user',
  `usrfullname` varchar(255) NOT NULL,
  `usremail` varchar(255) NOT NULL,
  `usrpassword` varchar(255) NOT NULL,
  `usrmobile` varchar(255) NOT NULL,
  `usrcity` varchar(255) NOT NULL,
  `usraddress` text NOT NULL,
  `usrstatus` tinyint(1) NOT NULL DEFAULT '0',
  `usrip` varchar(255) NOT NULL,
  `usrref` varchar(255) NOT NULL,
  `usruseragent` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usremailpassword` (`usremail`,`usrpassword`),
  KEY `usremail` (`usremail`),
  KEY `usrgroup` (`usrgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `usrgroup`, `usrfullname`, `usremail`, `usrpassword`, `usrmobile`, `usrcity`, `usraddress`, `usrstatus`, `usrip`, `usrref`, `usruseragent`, `created`, `modified`) VALUES
(3, 'root', 'Super Admin', 'admin@app.com', '21232f297a57a5a743894a0e4a801fc3', '91000000000', 'Mumbai', '', 1, '', '', '', '2016-03-23 14:59:54', '2016-03-23 16:35:31');
