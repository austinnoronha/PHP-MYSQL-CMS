<?php 

function get_conf($key=''){
	global $appConfig;
	return (isset($appConfig->$key)) ? $appConfig->$key : '';
}

function set_cookie($k,$v,$exp=0,$secure=0){
	$exp = ($exp) ? $exp:(time()+3600);
	return setcookie($k, base64_encode($v), $exp, "/", get_conf("app_ck_domain"), $secure);
}

function get_cookie($k){
	return (isset($_COOKIE[$k])) ? base64_decode($_COOKIE[$k]) : false;
}

function redirect_page($page=""){
	$url = get_site_url($page);
	header("Location:$url");
	die();
}

function get_site_url($page="", $mod="?mod="){
	$is_admin = get_conf("is_admin");
	$url = get_conf("app_url").'/';
	$index = get_conf("index_file");
	if($is_admin){
		$url .= get_conf("app_admin_fld")."/";
		$url .= ($index) ? $index:''; 
		$url .= "?";
		$url .= ($page) ? $page:''; 
	}else{
		if($index){
			$url .= $index;
			$url .= ($page) ? $mod.$page:''; 
		}
		else{
			$url .= ($page) ? $page:''; 
		}
	}	
	return $url;
}

function get_base_url(){
	$is_admin = get_conf("is_admin");
	$url = get_conf("base_url").'/';
	if($is_admin) $url .= get_conf("app_admin_fld")."/";
	return $url;
}

function __e($d='',$def=''){
	echo ((!empty ($d)) ? $d:$def);
}

function __log($d=''){
  $path = get_conf("app_logs_path");
	error_log("[".date("Y-m-d H:i:s")."]"."\t ".$d." \n",3,$path."/app.".date("Ymd").".log");
}

function __cnt($a=array()){
  if(is_array($a)){
    return count($a);
  }else{
    return -1;
  }
}
?>