<?php
/* @file	plugin.params
 * @date	April 2016
 * @summary	Constructs the JSON output
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginParams{
	
	public $response;

	function PluginParams(){
		$this->_init();
	}

	function _init(){
		//SEF QUERY STRING
		$path = (isset($_SERVER['PATH_INFO'])) ? $_SERVER['PATH_INFO'] : @getenv('PATH_INFO');
		if (trim($path, '/') != '' && $path != "/".SELF)
		{
			$tmp = explode("/",$path);
			array_shift($tmp);//pop first blank array
			$this->response['func'] = (isset($tmp[0])) ? array_shift($tmp):'';//pop the second param having the function name
			$this->response['params'] = $tmp;//assign the remaining as params
		}
		//NORMAL QUERY STRING
		$path = (isset($_SERVER['QUERY_STRING'])) ? $_SERVER['QUERY_STRING'] : @getenv('QUERY_STRING');
		if (trim($path, '/') != '')
		{
			$tmp = explode("&",$path);
			$k=0;
			while($t = each($tmp))
			{
				list($key,$val) = explode("=",$t["value"]);
				if($k == 0) 
					$this->response['func'] = $val;
				else 
					$this->response['params'][] = $val;//assign the remaining as params
				$k++;
			}
		}
		//GLOBAL GET
		if (is_array($_GET) && trim(key($_GET), '/') != '')
		{
			$this->response['func'] = (isset($_GET["func"])) ? $_GET["func"]:'';
			array_shift($_GET);//pop first function call
			while($t = each($_GET))
			{
				$this->response['params'][] = $t["value"];//assign the remaining as params
			}
		}	
	}

}

function plugin_allparams(){
	$objParams = PluginParams();
	if(is_array($s))
		return $objParams->response;
	else
		return;
}

function plugin_param($d=''){
	$set = '';
	if(isset($_GET[$d])){
		$set = $_GET[$d];
	}else if(isset($_POST[$d])){
		$set = $_POST[$d];
	}else if(isset($_REQUEST[$d])){
		$set = $_REQUEST[$d];
	}
	
	$set = trim($set);
	if(get_magic_quotes_gpc()){
		$set = stripslashes($set);
	}
	$set = htmlentities($set);
	
	return $set;
}
//EOF plugin.params
?>