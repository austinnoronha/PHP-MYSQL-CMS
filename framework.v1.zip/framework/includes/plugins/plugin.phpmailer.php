<?php
/* @file	plugin.phpmailer
 * @date	April 2016
 * @summary	Send Mail via phpmailer 
 * @desc	PHP Mialer is used ti sedn email with mail() of using smtp configuration
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginPhpMailer{
	
	public $fromemail, $fromname, $replyto;

	function PluginPhpMailer(){
		$this->_init();
	}

	function _init(){
		global $appConfig;
		$APP_PHPMAILER_PATH = $appConfig->app_includes_path . "/phpmailer";
		include_once( $APP_PHPMAILER_PATH . "/class.phpmailer.php" );
		include_once( $APP_PHPMAILER_PATH . "/class.smtp.php" );
	}

	function sendmail($to,$to_name='',$subject='',$message="",$cc='',$bcc=''){
		global $appConfig;
		if($appConfig->package_mail_info){
			$mail = new PHPMailer;
			
			if($appConfig->package_smtp){
				$mail->isSMTP();   
				// Set mailer to use SMTP
				$mail->Host = $appConfig->pk_smtp_host;										// Specify main and backup server
				if($appConfig->pk_smtp_auth){
					$mail->SMTPAuth = true;																	// Enable SMTP authentication
					$mail->Username = $appConfig->pk_smtp_user;             // SMTP username
					$mail->Password = $appConfig->pk_smtp_password;         // SMTP password	
				}
				$mail->SMTPSecure = $appConfig->pk_smtp_secure;						// Enable encryption, 'ssl' also accepted
			}
			else{
				$mail->isMail();   
			}

			//Set default from & replyto
			$mail->From = $appConfig->pk_mail_from;
			if($appConfig->pk_mail_fromname)
				$mail->FromName = $appConfig->pk_mail_fromname;

			if($appConfig->pk_mail_replyto)
				$mail->addReplyTo($appConfig->pk_mail_replyto);

			//set custom from & replyto
			if($this->fromemail) $mail->From = $this->fromemail;
			if($this->fromname) $mail->FromName = $this->fromname;
			if($this->replyto) $mail->addReplyTo($this->replyto);
			
			//to field
			if(is_array($to)){
				foreach($to as $to_item){
					$mail->addAddress($to_item);  // Add a recipient	- Name is optional
				}
			}
			else if(!empty($to)){
				$mail->addAddress($to,$to_name);  // Add a recipient	- Name is optional
			}
			
			//cc field
			if(is_array($cc)){
				foreach($cc as $cc_item){
					$mail->addCC($cc_item);  // Add a recipient	- Name is optional
				}
			}
			else if(!empty($cc)){
				$mail->addCC($cc);  // Add a recipient	- Name is optional
			}
			
			if(!empty($appConfig->pk_mail_cc)){
				$mail->addCC($appConfig->pk_mail_cc);	
			}

			//bcc field
			if(is_array($bcc)){
				foreach($bcc as $bcc_item){
					$mail->addBCC($bcc_item);  // Add a recipient	- Name is optional
				}
			}
			else if(!empty($bcc)){
				$mail->addBCC($bcc);  // Add a recipient	- Name is optional
			}
			
			if(!empty($appConfig->pk_mail_bcc)){
				$mail->addBCC($appConfig->pk_mail_bcc);
			}

			$mail->WordWrap = 50;

			// subject
			$subject = ($subject) ? $subject : $appConfig->pk_mail_subject;

			$mail->isHTML(true);									
			
			// Set email format to HTML
			$mail->Subject = $subject;
			$mail->Body    = $message;
			$tmp_alt_body = str_replace("\n","___NL___",$message);
			$tmp_alt_body = strip_tags($tmp_alt_body);
			$tmp_alt_body = str_replace("___NL___","\n",$tmp_alt_body);
			$mail->AltBody = $tmp_alt_body;
			
			if(!$mail->send()) {		
				return $mail->ErrorInfo;
			}
			return true;
		}
	}
}

function plugin_phpmailer($to,$to_name='',$subject='',$message="",$cc='',$bcc=''){
	$objMailer = PluginPhpMailer();
	//Alternative custom values
	//$objMailer->fromemail = ""; 
	//$objMailer->fromname = "";
	//$objMailer->replyto = "";

	return $objMailer->sendmail($to,$to_name='',$subject,$message,$cc,$bcc);
}
//EOF plugin.phpmailer
?>