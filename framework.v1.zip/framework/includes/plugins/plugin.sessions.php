<?php
/* @file	plugin.sessions
 * @date	April 2016
 * @summary	Construct the Pager
 * @desc	UL LI style pagination
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginSessions{
	
	public $app_sessions;

	function PluginSessions(){
		$this->_init();
	}

	function _init(){
		$this->app_sessions = array(
			"adminlogin" => "apAdml",
			"userlogin" => "apUslg",
			"loginemail" => "aplgeml",
			"loginname" => "aplgnme",
			"uniqid" => "apUqid"
		);
	}

	function set_session($key, $val){
		$_SESSION[$this->app_sessions[$key]] = $val;
	}

	function get_session($key){
		return (isset($_SESSION[$this->app_sessions[$key]])) ? $_SESSION[$this->app_sessions[$key]] : "";
	}

	function unset_session($key){
		if(isset($_SESSION[$this->app_sessions[$key]])) session_unset($_SESSION[$this->app_sessions[$key]]);
	}

	function destroy_session(){
		session_destroy();
	}
}

$objSessions = new PluginSessions();
function plugin_set_adminlogin($val){
	global $objSessions;
	$objSessions->set_session("adminlogin", $val);
}
function plugin_get_adminlogin(){
	global $objSessions;
	return $objSessions->get_session("adminlogin");
}

function plugin_set_userlogin($val){
	global $objSessions;
	$objSessions->set_session("userlogin", $val);
}
function plugin_get_userlogin(){
	global $objSessions;
	return $objSessions->get_session("userlogin");
}

//EOF plugin.sessions
?>