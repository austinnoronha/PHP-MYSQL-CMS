<?php
/* @file	plugin.outputjson
 * @date	April 2016
 * @summary	Constructs the JSON output
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginOutputJson{
	
	public $ajaxid;

	function PluginOutputJson(){
		$this->_init();
	}

	function _init(){
		global $appConfig;	
		$this->ajaxid = $appConfig->ajax_id;
	}

	function jsonOutput($s=array(), $nocache=true){
		if($nocache){
			header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
			header("Cache-Control: post-check=0, pre-check=0", false);
			header("Pragma: no-cache");
		}
		$tmp_ar = array();
		$tmp_ar[$this->ajaxid] = $s;

		echo json_encode($tmp_ar);
		die();
	}
}

function plugin_outputjson($s=array(), $nocache=true){
	$objPager = new PluginOutputJson();
	if(is_array($s))
		return $objPager->jsonOutput($s, $nocache);
	else
		return;
}
//EOF plugin.outputjson
?>