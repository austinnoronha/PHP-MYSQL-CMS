<?php
/* @file	plugin.clientheaders
 * @date	April 2016
 * @summary	Get client header info
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginClientHeaders{
	
	public $response;

	function PluginClientHeaders(){
		$this->_init();
	}

	function _init(){
		$this->response = array(
			"ip" => $this->getAppClientIP(),
			"referrer" => $this->getAppClientReferrer(),
			"useragent" => $this->getAppClientUserAgent(),
			"ismobile" => $this->isMobile()
		);
	}

	function getAppClientIP() {
			 $ipaddress = '';
			 if ($_SERVER['HTTP_CLIENT_IP'])
					 $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
			 else if($_SERVER['HTTP_X_FORWARDED_FOR'])
					 $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
			 else if($_SERVER['HTTP_X_FORWARDED'])
					 $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
			 else if($_SERVER['HTTP_FORWARDED_FOR'])
					 $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
			 else if($_SERVER['HTTP_FORWARDED'])
					 $ipaddress = $_SERVER['HTTP_FORWARDED'];
			 else if($_SERVER['REMOTE_ADDR'])
					 $ipaddress = $_SERVER['REMOTE_ADDR'];
			 else
					 $ipaddress = 'UNKNOWN';

			 return $ipaddress; 
	}

	function getAppClientReferrer(){
		return (isset($_SERVER["HTTP_REFERER"])) ? $_SERVER["HTTP_REFERER"] : "UNKNOWN";
	}

	function getAppClientUserAgent(){
		return (isset($_SERVER['HTTP_USER_AGENT'])) ? $_SERVER['HTTP_USER_AGENT'] : "UNKNOWN"; 
	}
	
	function isMobile() {
			$is_mobile = '0';

			if(preg_match('/(android|up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
					$is_mobile=1;
			}

			if((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml')>0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
					$is_mobile=1;
			}

			$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'],0,4));
			$mobile_agents = array('w3c ','acs-','alav','alca','amoi','andr','audi','avan','benq','bird','blac','blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno','ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-','maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-','newt','noki','oper','palm','pana','pant','phil','play','port','prox','qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar','sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-','tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp','wapr','webc','winw','winw','xda','xda-');

			if(in_array($mobile_ua,$mobile_agents)) {
					$is_mobile=1;
			}

			if (isset($_SERVER['ALL_HTTP'])) {
					if (strpos(strtolower($_SERVER['ALL_HTTP']),'OperaMini')>0) {
							$is_mobile=1;
					}
			}

			if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows')>0) {
					$is_mobile=0;
			}

			return $is_mobile;
	}
}

function plugin_clientheaders(){
	$objClnHd = PluginClientHeaders();
	return $objClnHd->response;
}
//EOF plugin.clientheaders
?>