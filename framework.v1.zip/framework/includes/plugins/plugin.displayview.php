<?php
/* @file	plugin.displayview
 * @date	April 2016
 * @summary	Constructs the JSON output
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginDisplayView{
	
	public $is_admin, $templates_path, $content_path;

	function PluginDisplayView(){
		$this->_init();
	}

	function _init(){
		global $appConfig;
		$this->is_admin = $appConfig->is_admin;
		$this->templates_path = $appConfig->app_templates_path;
		$this->content_path = $appConfig->app_content_path;
	}
	
	function display($view='',$data=array(),$ajax=0){
		$base = $this->content_path;
		if($this->is_admin){
			$base = $this->templates_path;
		}

		$viewfile = $base."/".$view.".php";
		
		if(is_file($viewfile)){
			extract($data);
			if($ajax){
				include_once($viewfile);
			}else{
				include_once($base."/header.php");
				include_once($viewfile);
				include_once($base."/footer.php");
			}
		}
	}
}

function plugin_displayview($view='',$data=array(),$ajax=0){
	$objDisplay = new PluginDisplayView();
	if(!empty($view))
		return $objDisplay->display($view,$data,$ajax);
	else
		return;
}

//EOF plugin.displayview
?>