<?php
/* @file	plugin.uploader
 * @date	April 2016
 * @summary	Application Uploader for Media/File
 * @desc	This is the common uploader function used for any medi or files uploads
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginUploader{
	
	public $image_resize, $base_path, $base_url, $filename_add_ts, $uploaded_info;

	function PluginUploader(){
		$this->_init();
	}

	function _init(){
		global $appConfig;

		$APP_INC_PATH = $appConfig->app_includes_path . "/imageresize";
		include_once($APP_INC_PATH . "/resize.class.php");

		if(is_array($appConfig->app_image_resize)){
			$this->image_resize = $appConfig->app_image_resize;
		}else{
			$this->image_resize = array("large" => 640, "medium" => 150, "small" => 100, "tiny" => 50);	
		}
		
		$this->base_path = $appConfig->app_media_path;
		$this->base_url = $appConfig->app_media_url;
		$this->filename_add_ts = true;
		$this->uploaded_info = false;
	}

	function uploadFile($s){
		$upload_source    = $s["tmp_name"];
		$upload_filename  = $s["name"];
		$upload_filetype  = $s["type"];
		$upload_filesize  = $s["size"];
		$upload_error     = $s["error"];
		
		$media_path		= $this->base_path;
		$tmp_pathinfo = pathinfo($upload_filename);
		$ext					= strtolower($tmp_pathinfo["extension"]);

		$upload_filename		= strtolower(preg_replace("#[^a-z0-9-]#i", "_", $tmp_pathinfo["filename"]));
		if($this->filename_add_ts){
			$new_filename_spcl	= $upload_filename."_".time()."_".date("jSMY");
			$new_filename = $new_filename_spcl.".".$ext;	
		}
		else{
			$new_filename = $upload_filename.".".$ext;
		}
		$destination = $media_path."/".$new_filename;
		
		if($upload_filesize <= 0){
			$this->uploaded_info = array(
				"status"		=> "failure",
				"message"		=> "filesize is 0",
				"filename"		=> $new_filename,
				"size"			=> $upload_filesize,
				"type"			=> $upload_filetype,
				"filepath"		=> $destination
			);
		}

		if(!move_uploaded_file($upload_source, $destination)){
			$this->uploaded_info = array(
				"status"		=> "failure",
				"message"		=> "File could not be uploader",
				"filename"		=> $new_filename,
				"size"			=> $upload_filesize,
				"type"			=> $upload_filetype,
				"filepath"		=> $destination
			);
		}else{
			$this->uploaded_info = array(
				"status"		=> "success",
				"filename"		=> $new_filename,
				"size"			=> $upload_filesize,
				"type"			=> $upload_filetype,
				"filepath"		=> $destination,
				"fileurl"		=> $this->base_url."/".$new_filename
			);
		}

		return $this->uploaded_info;
	}

	function getMediaPath($f=''){
		$media_path = $this->base_path;
		$destination = $media_path."/".$f;
		if(is_file($destination))
			return $destination;
		else
			return false;
	}

	function getMediaUrl($f=''){
		$media_path = $this->base_url;
    $destination = $media_path."/".$f;
    return $destination;
	}

	function resizeImage($file, $width=300, $height=300, $options="auto"){
		if(empty($file)) return false;

		$tmp_filepath = $this->getMediaPath($file);
		$media_path		= $this->base_path;
		$tmp_pathinfo = pathinfo($upload_filename);
		$ext					= strtolower($tmp_pathinfo["extension"]);

		if(!empty($tmp_filepath)){
			$tmp_img_ar = array("jpg","jpeg","gif","png","tiff");
			$resize_width = (int) $width;
			$resize_height = (int) $height;

			if(in_array($ext, $tmp_img_ar)){
				$new_filename_thumb = "rez_".$resize_width."x".$resize_height."_".$file;
				$destination_thumb = $media_path."/".$new_filename_thumb;
				
				// *** 1) Initialise / load image
				$resizeObj = new resize($destination);
				// *** 2) Resize image (options: exact, portrait, landscape, auto, crop)
				$resizeObj -> resizeImage($resize_width, $resize_height, $options);
				// *** 3) Save image
				$resizeObj -> saveImage($destination_thumb, 100);

				$response = array(
					"filename" => $new_filename_thumb,
					"filepath" => $destination_thumb,
					"fileurl" => $this->getMediaUrl($new_filename_thumb),
					"width" => $width,
					"height" => $height
				);
			}
		}
		return false;
	}
}

function plugin_uploader($s=array()){
	$objUploader = PluginUploader();
	if(is_array($s))
		return $objUploader->uploadFile($s);
	else
		return;
}

function plugin_media_filepath($s=array()){
	$objUploader = PluginUploader();
	if(!empty($s))
		return $objUploader->getMediaPath($s);
	else
		return;
}


function plugin_media_url($s=array()){
	$objUploader = PluginUploader();
	if(!empty($s))
		return $objUploader->getMediaUrl($s);
	else
		return;
}


function plugin_image_resize($file, $width=300, $height=300, $options="auto"){
	$objUploader = PluginUploader();
	if(!empty($file))
		return $objUploader->resizeImage($file, $width, $height, $options);
	else
		return;
}
//EOF plugin.uploader
?>