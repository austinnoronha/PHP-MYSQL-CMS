<?php
/* @file	plugin.logger
 * @date	April 2016
 * @summary	Constructs the JSON output
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;

class PluginLogger{
	
	public $LOG_PATH, $log_date, $log_uniq_key, $log_filename, $log_prefix, $log_affix, $log_type_format;

	function PluginLogger(){
		$this->_init();
	}

	function _init(){
		global $appConfig;
		$this->LOG_PATH = $appConfig->app_logs_path;
		$this->log_date = date("Y-m-d H:i:s");
		$this->log_uniq_key = "";
		$this->log_filename = "logger";
		$this->log_prefix = "app_";
		$this->log_affix = "log";
		$this->log_type_format = date("Ymd");
	}

	function logstr($str){
		$filename = $this->log_prefix."_".$this->log_filename."_".$this->log_type_format.".".$this->log_affix;
		error_log("[".$this->log_date."]"."\t ".$str."\n", 3 , $this->LOG_PATH."/".$filename);
	}
}

$objLogger = new PluginLogger();
function plugin_logger($s="", $log_date="", $log_uniq_key="", $log_filename=""){
	global $objLogger;

	//$objLogger->LOG_PATH = $appConfig->app_logs_path;
	//$objLogger->log_date = $log_date;
	//$objLogger->log_uniq_key = $log_uniq_key;
	//$objLogger->log_filename = $log_filename;

	if(!empty($s))
		$objLogger->logstr($s);
}
//EOF plugin.logger
?>