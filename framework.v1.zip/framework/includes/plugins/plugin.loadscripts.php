<?php
/* @file	plugin.loadscripts
 * @date	April 2016
 * @summary	Constructs the JSON output
 * @desc	-
 * @version	1.0
 * @package plugin
 */

global $appConfig;
$app_header_enqueue_scripts = array();
$app_footer_enqueue_scripts = array();

function plugin_loadscript($file, $place="header"){
	global $appConfig, $app_header_enqueue_scripts, $app_footer_enqueue_scripts;
	if($place === "header"){
		$app_header_enqueue_scripts[] = $file;
	}
	else{
		$app_footer_enqueue_scripts[] = $file;
	}
}

function plugin_generate_scripts($type = "header"){
	global $appConfig, $app_header_enqueue_scripts, $app_footer_enqueue_scripts;
	
	if($type === "header"){
		$tmp_scripts = $app_header_enqueue_scripts;
	}
	else{
		$tmp_scripts = $app_footer_enqueue_scripts;
	}

	foreach($tmp_scripts as $val){
		$assets_path = $appConfig->app_assets_url;
		$file = $assets_path . "/".$val;
		$tmp_fileinfo = pathinfo($val);
		if(stripos($tmp_fileinfo["extension"], "js") !== false){
			$html = <<<EOF
<script type="text/javascript" lang="javascript" src="$file"></script>\n
EOF;
		}
		else{
			$html = <<<EOF
<link rel="stylesheet" href="$file">\n
EOF;
		}
		
		echo $html;
	}
}

function plugin_script_js($js){
	global $appConfig;
	$assets_path = $appConfig->app_assets_url;
	$file = $assets_path . "/".$js;		
	$html = <<<EOF
<script type="text/javascript" lang="javascript" src="$file"></script>\n
EOF;
	echo $html;
}

function plugin_script_css($css){
	global $appConfig;
	$assets_path = $appConfig->app_assets_url;
	$file = $assets_path . "/".$css;		
	$html = <<<EOF
<link rel="stylesheet" href="$file">\n
EOF;
	echo $html;
}
//EOF plugin.loadscripts
?>