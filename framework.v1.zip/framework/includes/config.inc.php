<?php
/* @file	config.inc.php - Config File
 * @date	April 2016
 * @summary	This fill has all the Application Configuation Settings
 * @desc	-
 * @version	1.0
 * @copyright 2016 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

session_start();

/** @global string|integer error_reporting Options are E_ALL^E_WARNING^E_NOTICE | E_ALL^E_NOTICE | 0 */
error_reporting(E_ALL^E_NOTICE);

define("CONF_PRODUCTION", false);
define("CONF_KEY", "sjd99");

class MainConfig{};
$appConfig = new MainConfig(); 
$appConfig->cwd = "__CWD__";
$appConfig->appkey = CONF_KEY;

//APP SITE DATA PACKAGE
$appConfig->app_url				= "http://__DOMAIN_NAME__";
$appConfig->app_ck_domain		= "__DOMAIN_NAME__";
$appConfig->app_path			= $appConfig->cwd;
$appConfig->app_admin_fld		= "appadmin";
$appConfig->is_admin			= 0;
$appConfig->index_file			= "index.php";

$appConfig->app_templates_path	= $appConfig->app_path . "/templates";
$appConfig->app_content_path	= $appConfig->app_path . "/content";
$appConfig->app_logs_path		= $appConfig->app_path . "/logs";
$appConfig->app_includes_path	= $appConfig->app_path . "/includes";
$appConfig->app_modules_path	= $appConfig->app_path . "/modules";


$appConfig->app_assets_path	= $appConfig->app_path . "/assets";
$appConfig->app_assets_url	= $appConfig->app_url . "/assets";

$appConfig->app_media_path	= $appConfig->app_assets_path . "/media";
$appConfig->app_media_url	= $appConfig->app_assets_url . "/media";

//IMAGES PACKAGE
$appConfig->app_image_resize = array("large" => 640, "medium" => 150, "small" => 100, "tiny" => 50);

//GENERAL ERROR MESSAGESPACKAGE
$appConfig->app_error_connection	= "Sorry, connection could not be established. Please try later";

//MAIL PACKAGE
$appConfig->package_mail_info = false;
$appConfig->pk_mail_subject = "Subject";
$appConfig->pk_mail_from = "user@domain.com";
$appConfig->pk_mail_fromname = "User Name";
$appConfig->pk_mail_cc = "cc@domain.com";
$appConfig->pk_mail_bcc = "bcc@domain.com";
$appConfig->pk_mail_replyto = "replyto@domain.com";

//SMTP PACKAGE
$appConfig->package_smtp = false;
$appConfig->pk_smtp_auth = false;
$appConfig->pk_smtp_host = "__SMTP_HOST__";
$appConfig->pk_smtp_user = "__SMTP_USER__";
$appConfig->pk_smtp_password = "__SMTP_PASSWORD__";
$appConfig->pk_smtp_secure = "tls";

//MySQL DB PACKAGE
$appConfig->package_mysql = true;
$appConfig->pk_db_info = array();
if(CONF_PRODUCTION){
	$appConfig->pk_db_info = array("host" => "localhost", "username" => "", "password" => ".", "dbname" => "");
}
else{
	$appConfig->pk_db_info = array("host" => "localhost", "username" => "", "password" => "", "dbname" => "");
}

//OTHER PACKAGE
$appConfig->css_refresh_key = "";
$appConfig->data_sep = ".NbS.";
$appConfig->ajax_id = "app";


//include function file
include_once($appConfig->app_includes_path."/functions.inc.php");

//Autoload the classes
function nb_autoloader($class) {
	global $appConfig;
	//if the class exists dont load it
	if (class_exists($class)) return;
	try{
		$mod = $appConfig->app_modules_path . '/' . $class . '.class.php';
		if(is_file($cls))
			include $cls;
		else if(is_file($mod))
			include $mod;
			
	}catch(Exception $e){
		__log( 'Autoloader Message: Class: '.$class .' ::: ' .$e->getMessage() );
		return -1;
	}
}

spl_autoload_register('nb_autoloader');

//Create DB Connection
if($appConfig->package_mysql){
	$appConfig->db = new db_driver($appConfig->pk_db_info);
	$appConfig->db->connect();
	$appConfig->records_limit = 20;
}

//inlude plugins
include_once($appConfig->app_includes_path."/plugins/plugin.outputjson.php");
include_once($appConfig->app_includes_path."/plugins/plugin.displayview.php");
include_once($appConfig->app_includes_path."/plugins/plugin.logger.php");
include_once($appConfig->app_includes_path."/plugins/plugin.clientheaders.php");
include_once($appConfig->app_includes_path."/plugins/plugin.pager.php");
include_once($appConfig->app_includes_path."/plugins/plugin.params.php");
include_once($appConfig->app_includes_path."/plugins/plugin.phpmailer.php");
include_once($appConfig->app_includes_path."/plugins/plugin.uploader.php");
include_once($appConfig->app_includes_path."/plugins/plugin.loadscripts.php");
include_once($appConfig->app_includes_path."/plugins/plugin.sessions.php");

//EOF config.inc.php
?>